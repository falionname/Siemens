﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: Guid("3dc49793-2b02-4750-b1e7-fb468c310d05")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyKeyName("")]
[assembly: AssemblyDelaySign(false)]
[assembly: CompilationRelaxations(8)]
[assembly: ComVisible(false)]
[assembly: AssemblyDescription("西门子连接助手")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyTrademark("")]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: AssemblyCopyright("")]
[assembly: AssemblyTitle("SiemensConnection")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("SiemensConnection")]
