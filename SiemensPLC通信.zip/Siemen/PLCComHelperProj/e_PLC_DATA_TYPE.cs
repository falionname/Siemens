﻿using System;

namespace PLCComHelperProj
{

	public enum e_PLC_DATA_TYPE
	{
		TYPE_UNKNOW,
		TYPE_INT,
		TYPE_FLOAT,
		TYPE_BOOL,
		TYPE_SHORT,
		TYPE_BYTE
	}
}
